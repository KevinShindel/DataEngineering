# Databricks notebook source
version = "v3.0.69"
if not version.startswith("v"): library_url = f"git+https://github.com/databricks-academy/dbacademy@{version}"
else: library_url = f"https://github.com/databricks-academy/dbacademy/releases/download/{version}/dbacademy-{version[1:]}-py3-none-any.whl"
pip_command = f"install --quiet --disable-pip-version-check {library_url} google-api-python-client google-auth-httplib2 google-auth-oauthlib"

# COMMAND ----------

# MAGIC %md See also [/Source/Includes/_common]($../Source/Includes/_common)

# COMMAND ----------

# MAGIC %pip $pip_command

# COMMAND ----------

import dbacademy