# Databricks notebook source
# MAGIC %md # Update i18n GUIDs
# MAGIC This script is responsible for injecting GUIDs into existing courseware where it expects to find the tag **`--i18n-TBD`**
# MAGIC
# MAGIC **CAUTION - DO NOT RUN THIS SCRIPT WITH PENDING CHANGES**<br/>
# MAGIC While the net effect **should** be to take the existing content, inject the i18n GUID, and push that content back, it is highly advised that this script **NOT** be ran with pending changes in the workspace.

# COMMAND ----------

# MAGIC %md
# MAGIC **PLEASE** Do not update this script without contributing updates back to the **example-couse-source** and **template-course-source**, both located in the **/Repos/Examples & Tools** folder.

# COMMAND ----------

# MAGIC %run ./_libraries

# COMMAND ----------

import os

path = "/"+"/".join(os.getcwd().split("/")[2:-1])+"/Source"
print(path)

# COMMAND ----------

import json
from dbacademy.dbrest import DBAcademyRestClient

client = DBAcademyRestClient()
paths = [n.get("path") for n in client.workspace().ls(path, True)]

for p in paths:
    print(p)

# COMMAND ----------

import re
import uuid

key = "--i18n-TBD"

def get_start(a, contents, prefix):
    l = len(prefix)
    return contents[a:a+l]

def get_end(a, b, contents, prefix):
    l = len(prefix)
    return contents[a+l+1:b]

def find_b(a, contents):
    b = contents.find("\n", a)
    return len(contents) if b < 0 else b

def update_match(contents, line, prefix, updated, a, b):
    # %md is the last of the line, just add the GUID
    if updated:
        print("-"*80)
    else:
        print("="*80)
        print(notebook_path[len(path):])
        
    print(line)
    
    l = len(prefix)
    contents = f"{contents[:a+l]} --i18n-{uuid.uuid4()}\n{contents[a+l+1:]}" 
    
    b = find_b(a+1, contents)
    line = contents[a:b]
    print(line)
    
    return contents, True
    
def update_long(contents, line, magic, prefix, updated, a, b):
    start = get_start(a, contents, prefix)
    end = get_end(a, b, contents, prefix)
    
    if end.strip().startswith("--i18n"):
        # %md line is too long, but it is because it's an i18n GUID
        return contents, False
    
    else:
        # %md line is too long, need to wrap contents to the next line
        if updated:
            print("-"*80)
        else:
            print("="*80)
            print(notebook_path[len(path):])
            
        print(line)
        
        l = len(prefix)
        contents = f"{contents[:a+l]} --i18n-{uuid.uuid4()}\n{magic}\n{magic} {contents[a+l+1:]}" 
        b = find_b(a+1, contents)
        b = find_b(b+1, contents)
        b = find_b(b+1, contents)
        line = contents[a:b]
        print(line)
        
        return contents, True
    

# COMMAND ----------

for notebook_path in paths:

    magics = ["# MAGIC", "-- MAGIC", "// MAGIC"]
    for magic in magics:
        
        prefix = f"{magic} %md"
        results = client.workspace().get_status(notebook_path)
        language = results.get("language")
        contents = client.workspace().export_notebook(notebook_path)
        
        a = contents.find(prefix)
        updated = False
        
        while a >= 0:
            b = find_b(a, contents)
            line = contents[a:b].strip()
            
            if len(line) < len(prefix):
                raise Exception("This should never happen")
                
            elif len(line) == len(prefix):
                contents, updated = update_match(contents, line, prefix, updated, a, b)
                
            elif len(line) > len(prefix):
                contents, updated = update_long(contents, line, magic, prefix, updated, a, b)
                
            a = contents.find(prefix, a+1)
            
        client.workspace().import_notebook(language, notebook_path, contents)
