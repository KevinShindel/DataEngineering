# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC # Publish Assets

# COMMAND ----------

# DBTITLE 1,Step #1: Load Libraries
# MAGIC %run ./_libraries

# COMMAND ----------

# DBTITLE 1,Step #2: Load Config
from dbacademy.dbbuild import BuildConfig

build_config = BuildConfig.load("_build-config.json", version="1.0.0")
build_config.validate()

# COMMAND ----------

# DBTITLE 1,Step #3: Validate All Tests Passed
build_config.validate_all_tests_passed("AWS")
build_config.validate_all_tests_passed("MSA")
build_config.validate_all_tests_passed("GCP")

# COMMAND ----------

# DBTITLE 1,Step #4: Start Publish
publisher = build_config.to_publisher(publishing_mode="manual")
print()
publisher.validate()

# COMMAND ----------

# DBTITLE 1,Step #5: Check for Changes
publisher.validate_no_changes_in_source_repo()

# COMMAND ----------

# DBTITLE 1,Step #6: Generate Notebooks
html = publisher.generate_notebooks()
displayHTML(html)

# COMMAND ----------

# DBTITLE 1,Step #7: Publish DBC Files to the CDS
html = publisher.create_dbcs()
displayHTML(html)

# COMMAND ----------

# DBTITLE 1,Step #8: Publish PDF Files to the CDS
html = publisher.create_docs()
displayHTML(html)

# COMMAND ----------

# DBTITLE 1,Step #9: Validate Artifacts
publisher.validate_artifacts()

# COMMAND ----------

# DBTITLE 1,Step #10: Advertise Changes
html = publisher.create_published_message()
displayHTML(html)