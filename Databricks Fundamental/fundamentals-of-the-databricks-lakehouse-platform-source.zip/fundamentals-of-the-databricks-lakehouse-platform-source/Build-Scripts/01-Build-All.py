# Databricks notebook source
# MAGIC %md
# MAGIC # Build All

# COMMAND ----------

# DBTITLE 1,Step #1: Load Libraries
# MAGIC %run ./_libraries

# COMMAND ----------

# DBTITLE 1,Step #2: Load Config
from dbacademy.dbbuild import BuildConfig

build_config = BuildConfig.load("_build-config.json", version="Build")
build_config.validate()

# COMMAND ----------

# DBTITLE 1,Step #3: Start Publish
publisher = build_config.to_publisher()
publisher.validate()

# COMMAND ----------

# DBTITLE 1,Step #4: Generate Notebooks
html = publisher.generate_notebooks()
displayHTML(html)