# Databricks notebook source
# MAGIC %md 
# MAGIC # Test Build

# COMMAND ----------

# DBTITLE 1,Step #1: Load Libraries
# MAGIC %run ./_libraries

# COMMAND ----------

# DBTITLE 1,Step #2: Load Config
from dbacademy.dbbuild import BuildConfig

build_config = BuildConfig.load("_build-config.json", version="Test")
build_config.validate()

# COMMAND ----------

# DBTITLE 1,Step #3: Start Publish
publisher = build_config.to_publisher()
publisher.validate()

# COMMAND ----------

# DBTITLE 1,Step #4: Generate Notebooks
html = publisher.generate_notebooks()
displayHTML(html)

# COMMAND ----------

# DBTITLE 1,Step #5: Execute Tests
test_suite = publisher.to_test_suite()
test_suite.reset()

if test_suite.test_all_synchronously(1):
    test_suite.test_all_asynchronously(2)

test_suite.cleanup()
evaluator = test_suite.to_results_evaluator()

# COMMAND ----------

# DBTITLE 1,Step #6: Review Test Results
html = evaluator.to_html()
displayHTML(html)

# COMMAND ----------

assert evaluator.passed, "One or more failures detected"