# Databricks notebook source
# INCLUDE_HEADER_TRUE
# INCLUDE_FOOTER_TRUE

# COMMAND ----------

# MAGIC %md
# MAGIC # Project Information
# MAGIC
# MAGIC * Name: **{{course_name}}**
# MAGIC * Version:  **{{version_number}}**
# MAGIC * Built On: **{{built_on}}**

# COMMAND ----------

# TROUBLESHOOTING_CONTENT

# COMMAND ----------

# MAGIC %md ## Copyrights
# MAGIC This section documents the various copyrights as they relate to the datasets used in this course.
# MAGIC
# MAGIC Run the following cell for additional information on this course's datasets, and their copyrights.

# COMMAND ----------

# MAGIC %run ./Includes/Print-Dataset-Copyrights